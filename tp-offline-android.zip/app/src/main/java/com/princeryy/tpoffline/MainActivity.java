package com.princeryy.tpoffline;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * TP Offline: membungkus halaman web (assets/www) dalam WebView tanpa akses internet.
 * File hasil (ZIP, PNG, JSON) disimpan langsung ke folder Download lewat AndroidBridge.
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final int REQ_FILE = 1001;
    private static final int REQ_STORAGE = 1002;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        // Android 9 ke bawah butuh izin tulis untuk menyimpan ke Download
        if (Build.VERSION.SDK_INT < 29
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
        }

        web = new WebView(this);
        setContentView(web);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                // Hanya halaman internal yang boleh dibuka
                return !HOST.equals(r.getUrl().getHost());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*"); // tidak dibatasi: .plist/.zip sering tidak punya MIME yang dikenal
                if (p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                try {
                    startActivityForResult(Intent.createChooser(i, "Pilih file"), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        if (state != null) {
            web.restoreState(state);
        } else {
            web.loadUrl("https://" + HOST + "/assets/www/index.html");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCallback != null) {
            Uri[] r = WebChromeClient.FileChooserParams.parseResult(res, data);
            fileCallback.onReceiveValue(r);
            fileCallback = null;
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("AndroidBridge");
            web.destroy();
        }
        super.onDestroy();
    }

    /** Jembatan JS -> Android: menerima file per potongan (base64) lalu menaruhnya di Download. */
    public class Bridge {
        private OutputStream out;
        private File tmp;
        private String name, mime;

        @JavascriptInterface
        public synchronized String begin(String fileName, String mimeType) {
            try {
                closeQuietly();
                name = safeName(fileName);
                mime = (mimeType == null || mimeType.isEmpty()) ? "application/octet-stream" : mimeType;
                tmp = File.createTempFile("dl", ".tmp", getCacheDir());
                out = new BufferedOutputStream(new FileOutputStream(tmp));
                return "OK";
            } catch (Exception e) {
                return "ERR:" + e.getMessage();
            }
        }

        @JavascriptInterface
        public synchronized String chunk(String base64) {
            try {
                if (out == null) return "ERR:sesi simpan belum dimulai";
                out.write(Base64.decode(base64, Base64.DEFAULT));
                return "OK";
            } catch (Exception e) {
                closeQuietly();
                return "ERR:" + e.getMessage();
            }
        }

        @JavascriptInterface
        public synchronized String end() {
            try {
                if (out == null) return "ERR:sesi simpan belum dimulai";
                out.close();
                out = null;
                String shown = copyToDownloads(tmp, name, mime);
                return "OK:" + shown;
            } catch (Exception e) {
                return "ERR:" + e.getMessage();
            } finally {
                if (tmp != null) tmp.delete();
                tmp = null;
            }
        }

        private void closeQuietly() {
            try { if (out != null) out.close(); } catch (IOException ignored) { }
            out = null;
            if (tmp != null) tmp.delete();
            tmp = null;
        }
    }

    private static String safeName(String n) {
        String s = (n == null ? "file" : n).replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return s.isEmpty() ? "file" : s;
    }

    /** Menyalin file ke folder Download publik. Mengembalikan nama yang tampil, mis. "Download/atlas.zip". */
    private String copyToDownloads(File src, String name, String mime) throws IOException {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IOException("Tidak bisa membuat file di Download");
            try (InputStream in = new FileInputStream(src);
                 OutputStream o = getContentResolver().openOutputStream(uri)) {
                if (o == null) throw new IOException("Tidak bisa menulis ke Download");
                copy(in, o);
            } catch (IOException e) {
                getContentResolver().delete(uri, null, null);
                throw e;
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            getContentResolver().update(uri, done, null, null);
            String shown = name; // Android menambah " (1)" bila nama sudah ada
            try (Cursor c = getContentResolver().query(uri, new String[]{MediaStore.MediaColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) shown = c.getString(0);
            }
            return "Download/" + shown;
        }

        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            throw new IOException("Izin penyimpanan belum diberikan. Buka Pengaturan > Aplikasi > TP Offline > Izin.");
        }
        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Folder Download tidak bisa dibuat");
        File dst = uniqueFile(dir, name);
        try (InputStream in = new FileInputStream(src); OutputStream o = new FileOutputStream(dst)) {
            copy(in, o);
        }
        MediaScannerConnection.scanFile(this, new String[]{dst.getAbsolutePath()}, new String[]{mime}, null);
        return "Download/" + dst.getName();
    }

    private static File uniqueFile(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists()) return f;
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        for (int i = 1; ; i++) {
            f = new File(dir, base + " (" + i + ")" + ext);
            if (!f.exists()) return f;
        }
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }
}
