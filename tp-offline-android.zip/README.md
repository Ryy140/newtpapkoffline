# TP Offline

Texture Packer / Unpacker (plist format Naruto Senki) sebagai aplikasi Android **offline**.
Dikembangkan oleh **PrinceRyy**.

- Tanpa izin internet: font dan library ZIP sudah dibundel di dalam APK.
- Tombol unduh (ZIP, PNG, JSON) menyimpan **langsung ke folder Download** di HP.
- Ikon aplikasi memakai logo TP Offline (`icon-512.png`).

## Cara rilis APK lewat GitHub

1. Buat repository baru di GitHub, lalu upload seluruh isi folder ini (atau `git push`).
2. Pilih salah satu:
   - **Lewat tag:** `git tag v1.0.0 && git push origin v1.0.0`
   - **Lewat tombol:** tab **Actions** → **Build & Rilis APK** → **Run workflow** → isi tag (mis. `v1.0.0`).
3. Tunggu sekitar 3–5 menit. APK muncul di tab **Releases** dengan nama `TP-Offline-v1.0.0.apk`.
4. Unduh APK itu di Android, buka, dan izinkan "Install dari sumber ini" bila diminta.

## Tanda tangan tetap (disarankan)

Tanpa pengaturan ini, setiap rilis ditandatangani dengan kunci sementara sehingga versi baru
tidak bisa menimpa versi lama (harus uninstall dulu). Untuk membuat kunci tetap, sekali saja:

```bash
keytool -genkeypair -keystore tp-offline.jks -alias tpoffline -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 tp-offline.jks   # salin hasilnya
```

Lalu di GitHub: **Settings → Secrets and variables → Actions → New repository secret**, tambahkan:

| Secret | Isi |
|---|---|
| `KEYSTORE_BASE64` | hasil `base64` di atas |
| `KEYSTORE_PASSWORD` | password keystore |
| `KEY_ALIAS` | `tpoffline` |
| `KEY_PASSWORD` | password key (boleh sama dengan password keystore) |

Simpan file `tp-offline.jks` di tempat aman. Jangan di-commit.

## Struktur

- `web/` — halaman aplikasi (HTML/CSS/JS) + `vendor/jszip.min.js`
- `app/` — proyek Android (WebView + jembatan simpan ke Download)
- `tools/prepare-web.mjs` — menyalin `web/` ke aset APK dan membundel font
- `.github/workflows/release.yml` — build & rilis otomatis

## Build lokal (opsional)

Butuh JDK 17, Android SDK, dan Gradle 8.7:

```bash
npm --prefix tools install && node tools/prepare-web.mjs
gradle assembleRelease
```
