// Menyiapkan aset web untuk APK: menyalin web/ ke app/src/main/assets/www dan
// membundel font Plus Jakarta Sans secara lokal (agar benar-benar offline).
// Pakai:  npm --prefix tools install && node tools/prepare-web.mjs
import { cpSync, rmSync, mkdirSync, copyFileSync, writeFileSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const dest = join(root, 'app/src/main/assets/www');
const fontSrc = join(root, 'tools/node_modules/@fontsource/plus-jakarta-sans/files');

rmSync(dest, { recursive: true, force: true });
mkdirSync(dest, { recursive: true });
cpSync(join(root, 'web'), dest, { recursive: true });

const weights = [400, 500, 600, 700, 800];
mkdirSync(join(dest, 'fonts/files'), { recursive: true });
let css = '';
for (const w of weights) {
  const f = `plus-jakarta-sans-latin-${w}-normal.woff2`;
  const from = join(fontSrc, f);
  if (!existsSync(from)) { console.error(`Font tidak ditemukan: ${from}\nJalankan dulu: npm --prefix tools install`); process.exit(1); }
  copyFileSync(from, join(dest, 'fonts/files', f));
  css += `@font-face{font-family:"Plus Jakarta Sans";font-style:normal;font-display:swap;font-weight:${w};src:url(files/${f}) format("woff2")}\n`;
}
writeFileSync(join(dest, 'fonts/fonts.css'), css);

for (const f of ['index.html', 'icon.png', 'vendor/jszip.min.js', 'fonts/fonts.css']) {
  if (!existsSync(join(dest, f))) { console.error('Aset wajib tidak ada: ' + f); process.exit(1); }
}
console.log('Aset web siap di', dest);
